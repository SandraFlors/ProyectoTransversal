package universidad_grupo3;

import java.sql.Connection;
import java.time.LocalDate;
import universidad_grupo3.accesoAdatos.Conexion;
import universidad_grupo3.accesoAdatos.InscripcionData;
import universidad_grupo3.accesoAdatos.MateriaData;
import universidad_grupo3.entidades.Alumno;
import universidad_grupo3.entidades.Inscripcion;
import universidad_grupo3.entidades.Materia;
import universidad_grupo3.accesoAdatos.AlumnoData;

public class Universidad_Grupo3 {

    public static void main(String[] args) {

        Connection con = Conexion.getConexion();//llamo al metodo get conexion de la clase (CONEXION)
        //con (guardo en una variable de tipo conexion lo que me devolvera el metodo

////-------------------------------ALUMNODATA------------------------------------------------------------------------------------
        Alumno juan = new Alumno(12312333, "Lopez", "JuanPedro", LocalDate.of(1980, 4, 25), true);
        Alumno brenda = new Alumno(20020022, "Suares", "Brenda", LocalDate.of(1997, 5, 10), true);
        AlumnoData alu = new AlumnoData();//el alumno esta en la memoria ram , para guardarlo en la base de datos creamos alumnoData
//    
        //agregarmos un alumno (desde netbeans)atravez de alumno data hacia base de datos
        alu.guardarAlumno(juan); //alu.guardara el alumno juan
        alu.guardarAlumno(brenda);
        alu.modificarAlumno(juan);
        alu.eliminarAlumno(6);
//        System.out.println("");
        System.out.println("-------------------------Buscando alumno por Id: -------------------------------");
        Alumno alumnoEncontrado = alu.buscarAlumnoid(11);

        System.out.println("Alumno Encontrado! -Id:" + alumnoEncontrado.getIdAlumno() + " " + "-Dni" + alumnoEncontrado.getDni() + "-Apellido:" + alumnoEncontrado.getApellido());
        System.out.println("");

        System.out.println("------------------Buscar Alumno por DNI: -------------------");

        Alumno dniEncontrado = alu.buscarAlumnoDni(12312333);
        if (dniEncontrado != null) {
            System.out.print(" DNI " + dniEncontrado.getDni() + "-");
            System.out.print(" Apellido " + dniEncontrado.getApellido());
        }
        System.out.println(" ");
        System.out.println("-------------------------Lista de Alumnos: -----------------------");
        for (Alumno alumno : alu.listarAlumnos()) {
            System.out.print("Dni : " + alumno.getDni() + "_");
            System.out.print("Apellido: " + alumno.getApellido() + "_");
            System.out.print("Nombre: " + alumno.getNombre() + "_");
            System.out.print("FechaNacimiento: " + alumno.getFechaNac() + " ");
            System.out.println(" ");
        }
        System.out.print(" ");
        //---------------------------------------MATERIADATA--------------------------------------------------------------------------------------
        MateriaData mat = new MateriaData();

        Materia materia = new Materia("Laboratorio", 1, true);
        mat.guardarMateria(materia);

        Materia materiaencontrada = mat.buscarMateria(1);
        if (materiaencontrada != null) {
            System.out.println(" Nombre : " + materiaencontrada.getNombre());
            System.out.println("Año: " + materiaencontrada.getAnioMateria());
        }

        mat.modificarMateria(materia);

        mat.eliminarMateria(3);

        System.out.println("---------------Lista de Materias:--------------------------------");
        for (Materia mater : mat.listarMaterias()) {
            System.out.print(" Nombre Materia: " + mater.getNombre() + "_");
            System.out.print(" Año materia: " + mater.getAnioMateria() + "_");
            System.out.println(" Id Materia " + mater.getIdMateria());
            System.out.println(" ");
        }
        //------------------------------------INSCRIPCIONDATA-----------------------------------------------------------------------------------------
        InscripcionData in = new InscripcionData();

        Alumno juani = alu.buscarAlumnoid(11);
        Materia mate = mat.buscarMateria(24);
        Inscripcion insc = new Inscripcion(juani, mate, 9);//le pasamos alumno y materia y la nota

        in.guardarInscripcion(insc);
        in.actualizarNota(11, 24, 7);
        in.borrarInscripcionMateriaAlumno(30, 3);

        for (Inscripcion inscripcion : in.obtenerInscripciones()) {
            System.out.println("-----------------Inscripciones---------------------------");
            System.out.println("id : " + inscripcion.getIdInscripcion());
            System.out.println("Alumno: " + inscripcion.getAlumno());
            System.out.println("Materia : " + inscripcion.getMateria());
        }

        for (Inscripcion inscripcion : in.obtenerInscripcionesporAlumno(11)) {
            System.out.println("----------Inscripcion por alumno---------------");
            System.out.println("nombre " + inscripcion.getMateria());
            System.out.println("id " + inscripcion.getIdInscripcion());
        }

        for (Materia mater : in.obtenerMateriasCursadas(31)) {
            System.out.println("----------------------------Materias Cursadas----------------------------");
            System.out.println("Nombre " + mater.getNombre());

        }

        for (Materia mater : in.obtenerMateriasNOCursadas(28)) {
            System.out.println("-------------------Materias no Cursadas----------------------------------");
            System.out.println("nombre " + mater.getNombre());
        }

        for (Alumno mater : in.obtenerAlumnosporMaterias(24)) {
            System.out.println("-------------------Alumnos por Materias---------------------------------");
            System.out.println("nombre " + mater.getNombre());
        }
        //-----------------------------------------------------------------------------------------------------------------------------

    }

}
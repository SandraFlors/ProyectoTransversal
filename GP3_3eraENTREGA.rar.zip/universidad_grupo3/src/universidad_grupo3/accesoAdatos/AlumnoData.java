package universidad_grupo3.accesoAdatos;

import universidad_grupo3.entidades.Alumno;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class AlumnoData {

    private Connection con = null; //este objeto conection sera utilizado por los metodos de la clase alumno data
    //para guardar/aliminar/consultar datos de la BD

    public AlumnoData() { //constructor para  inizializar la variable conexion
        con = (Connection) Conexion.getConexion(); //getconexion se encargara de cargar drivers si es que no se realizo antes y establece la conexion con la BD
    }

    //--------------------------------------------------------------------------------------------------------------------------------------
    public void guardarAlumno(Alumno alumno) {//metodo guardar

        String sql = "INSERT INTO alumno(dni,apellido,nombre,fechaNacimiento,estado)" + "VALUES(?,?,?,?,?)";
        //datos BD de la sentencia insert--------------datos a enviar (?)
        try {
            PreparedStatement pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);//sentencia sql , le pedimos lista de claves generadas
            //remplazaremos los signos de pregunta (linea 20) por los datos que quiero enviar

            pre.setInt(1, alumno.getDni());
            pre.setString(2, alumno.getApellido());
            pre.setString(3, alumno.getNombre());
            pre.setDate(4, Date.valueOf(alumno.getFechaNac()));//date es la clase que se encuentra en java sql
            pre.setBoolean(5, alumno.isActivo());
            pre.executeUpdate(); //ejecutamos el preparedStatement

            ResultSet res = pre.getGeneratedKeys();//(clave generada de alumno) me devolvera un resulset (especie de tabla con 1 sola clumna id) tantas filas como alumnos haiga
            if (res.next()) {
                alumno.setIdAlumno(res.getInt("idAlumno"));//devolvemos al alumno con id
                JOptionPane.showMessageDialog(null, "alumno guardado exitosamente");
            }
            pre.close();//cerramos el objeto preparedstatement

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ingresar a la tabla alumno" + ex.getMessage());
        }

    }

    //----------------------------------------------------------------------------------------------------------------------------------------
    public Alumno buscarAlumnoid(int id) { //va a recibir un id y retornará alumno con ese id
        String sql = "SELECT dni,apellido,nombre,fechaNacimiento FROM alumno WHERE idAlumno=? AND estado=1"; //enviamos u SELECT  a la base de datos

        Alumno alumno = null;//variable alumno nula
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet re = pre.executeQuery();

            if (re.next()) {
                alumno = new Alumno();//le asignamos alumno vacio

                alumno.setIdAlumno(id); //seteamos datos a alumno en base a lo que me devuelve el rs
                alumno.setDni(re.getInt("dni"));
                alumno.setApellido(re.getString("apellido"));
                alumno.setNombre(re.getString("nombre"));
                alumno.setFechaNac(re.getDate("fechaNacimiento").toLocalDate());//convierte el get date en un local date
                alumno.setActivo(true);

            } else {
                JOptionPane.showMessageDialog(null, "No se encontró alumno con el Id ingresado");
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla alumno");
        }
        return alumno;
    }
    //----------------------------------------------------------------------------------------------------------------------------------------

    public Alumno buscarAlumnoDni(int dni) { //
        String sql = "SELECT idAlumno,dni,apellido,nombre,fechaNacimiento FROM alumno WHERE dni=? AND estado=1";

        Alumno alumno = null;//variable alumno nula
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, dni);
            ResultSet re = pre.executeQuery();

            if (re.next()) {
                alumno = new Alumno();

                alumno.setIdAlumno(re.getInt("idAlumno")); //seteamos datos a alumno en base a lo que me devuelve el rs
                alumno.setDni(re.getInt("dni"));
                alumno.setApellido(re.getString("apellido"));
                alumno.setNombre(re.getString("nombre"));
                alumno.setFechaNac(re.getDate("fechaNacimiento").toLocalDate());//convierte el get date en un local date
                alumno.setActivo(true);

            } else {
                JOptionPane.showMessageDialog(null, "No se encontró alumno con el DNI ingresado");
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla alumno");
        }
        return alumno;
    }

    //-----------------------------------------------------------------------------------------------------------------------------------------
    public List<Alumno> listarAlumnos() { //
        String sql = "SELECT idAlumno,dni,apellido,nombre,fechaNacimiento FROM alumno WHERE estado=1";
        ArrayList<Alumno> alumnos = new ArrayList<>();

        try {
            PreparedStatement pre = con.prepareStatement(sql);

            ResultSet re = pre.executeQuery();

            while (re.next()) {
                Alumno alumno = new Alumno();

                alumno.setIdAlumno(re.getInt("idAlumno")); //seteamos datos a alumno en base a lo que me devuelve el rs
                alumno.setDni(re.getInt("dni"));
                alumno.setApellido(re.getString("apellido"));
                alumno.setNombre(re.getString("nombre"));
                alumno.setFechaNac(re.getDate("fechaNacimiento").toLocalDate());//convierte el get date en un local date
                alumno.setActivo(true);

                alumnos.add(alumno);

            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla alumno");
        }
        return alumnos;
    }

    //-----------------------------------------------------------------------------------------------------------------------------------------
    //modicar alumno ,recibe un alumno existente de nuestra base de dato , podemos cambiarle algun dato
    public void modificarAlumno(Alumno alumno) {//metodo modif.alum , recibe un alumno existente en la base de datos (ya tiene un id)
        String sql = "UPDATE alumno SET dni=? , apellido=?, nombre=?,fechaNac=?" + "WHERE idAlumno=?";//(?) el dato lo van a pasar , 
        //cambiamos dni,apeliido ,nombre,fechan- (where) ----------------------(where) condicion para no actualizar todos los alum
        PreparedStatement pre = null;
        try {
            pre = con.prepareStatement(sql);// pS + connecion , pasamos parametros (sentencia sql).
            //puede lanzar una exepcion .

            pre.setInt(1, alumno.getDni());//le seteamos los parametros dinamicos ej: dni=?
            //----------------------------------le decimos que (?) es un entero que corresponde al id alumno que recibimos
            pre.setString(2, alumno.getApellido());
            pre.setString(3, alumno.getNombre());
            pre.setDate(4, Date.valueOf(alumno.getFechaNac()));
            pre.setInt(5, alumno.getIdAlumno());

            int exit = pre.executeUpdate();//devolvera un entero y lo guardaremos en una variable entera , en este caso EXIT

            if (exit == 1) { //si pudo actualizar al alumno mostraremos un msj , esto ocurrira si la variable entera exit tiene u valor=1 

                JOptionPane.showMessageDialog(null, "Alumno modificado");
            }

        } catch (SQLException ex) { //si se produce la SQLException mostrara el msj JOptionPane
            JOptionPane.showMessageDialog(null, "Error no puede acceder a la tabla alumno no se pudo modificar " + ex.getMessage());
        }

    }
    //--------------------------------------------------------------------------------------------------------------------------------- 

    public void eliminarAlumno(int id) {

        try {

            String sql = "UPDATE alumno SET estado=0 WHERE idAlumno=?";
            //update de alumno -set- solo el campo estado =0 del alumno que tiene como id el id que me pasan por parametro
            PreparedStatement pre = con.prepareStatement(sql); //puede lanzar una exepcion , encerramos en un try catch

            pre.setInt(1, id); //seteamos el parametro -remplamos el ? de la linea 87 por un id
            int exito = pre.executeUpdate(); //devolverá un entero
            //guardamos en exito el resultado del executeUpdate
            if (exito == 1) {
                JOptionPane.showMessageDialog(null, "Alumno eliminado!");
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "no se pudo eliminar el alumno" + ex.getMessage());
        }
    }
  
    
}

package universidad_grupo3.accesoAdatos;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import universidad_grupo3.entidades.Materia;

public class MateriaData {

    private Connection con = null;

    public MateriaData() { //constructor para  inizializar la variable materia
        con = (Connection) Conexion.getConexion();
    }

    //-----------------------------------------------------------------------------------------------------------------------------
    public void guardarMateria(Materia materia) {
        String sql = "INSERT INTO materia(nombre,año,estado)" + "VALUES(?,?,?)";
        try {
            PreparedStatement pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);//sentencia sql , le pedimos lista de claves generadas
            //remplazaremos los signos de pregunta (linea 22) por los datos que quiero enviar

            pre.setString(1, materia.getNombre());
            pre.setInt(2, materia.getAnioMateria());
            pre.setBoolean(3, materia.isActivo());
            pre.executeUpdate(); //ejecutamos el preparedStatement

            ResultSet res = pre.getGeneratedKeys();//(clave generada de alumno) me devolvera un resulset (especie de tabla con 1 sola clumna id) tantas filas como alumnos haiga
            if (res.next()) {
                materia.setIdMateria(res.getInt("idMateria"));//devolvemos al alumno con id
                JOptionPane.showMessageDialog(null, "Materia guardada exitosamente");
            }
            pre.close();//cerramos el objeto preparedstatement

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ingresar a la tabla Materia" + ex.getMessage());
        }
    }
    //-----------------------------------------------------------------------------------------------------------------------------

    public Materia buscarMateria(int id) { //va a recibir un id y retornará alumno con ese id
        String sql = "SELECT nombre,año,estado FROM materia WHERE idMateria=? AND estado=1"; //enviamos u SELECT  a la base de datos

        Materia materia = null;//variable alumno nula
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet re = pre.executeQuery();

            if (re.next()) {
                materia = new Materia();//le asignamos alumno vacio

                materia.setIdMateria(id); //seteamos datos a alumno en base a lo que me devuelve el rs
                materia.setNombre(re.getString("nombre"));
                materia.setAnioMateria(re.getInt("año"));
                materia.setActivo((true));

            } else {
                JOptionPane.showMessageDialog(null, "No se encontró Materia con la Id ingresada");
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Materia");
        }
        return materia;
    }
    //-----------------------------------------------------------------------------------------------------------------------------
    //modicar alumno ,recibe un alumno existente de nuestra base de dato , podemos cambiarle algun dato

    public void modificarMateria(Materia materia) {//metodo modif.alum , recibe un alumno existente en la base de datos (ya tiene un id)
        String sql = "UPDATE materia SET nombre=? , año=?" + "WHERE idMateria=?";//(?) el dato lo van a pasar , 
        //cambiamos dni,apeliido ,nombre,fechan- (where) ----------------------(where) condicion para no actualizar todos los alum
        PreparedStatement pre = null;
        try {
            pre = con.prepareStatement(sql);// pS + connecion , pasamos parametros (sentencia sql).
            //puede lanzar una exepcion .

            pre.setString(1, materia.getNombre());//le seteamos los parametros dinamicos ej: dni=?
            //----------------------------------le decimos que (?) es un entero que corresponde al id alumno que recibimos

            pre.setInt(2, materia.getAnioMateria());

            pre.setInt(3, materia.getIdMateria());

            pre.executeUpdate(); //ejecutamos el preparedStatement

            int exit = pre.executeUpdate();//devolvera un entero y lo guardaremos en una variable entera , en este caso EXIT

            if (exit == 1) { //si pudo actualizar al alumno mostraremos un msj , esto ocurrira si la variable entera exit tiene u valor=1 

                JOptionPane.showMessageDialog(null, "Materia modificado");
            }

        } catch (SQLException ex) { //si se produce la SQLException mostrara el msj JOptionPane
            JOptionPane.showMessageDialog(null, "Error no puede acceder a la tabla Materia no se pudo modificar " + ex.getMessage());
        }

    }
    //-----------------------------------------------------------------------------------------------------------------------------
    
     public void eliminarMateria(int id) {

        try {

            String sql = "UPDATE materia SET estado=0 WHERE idMateria=?";
            //update de alumno -set- solo el campo estado =0 del alumno que tiene como id el id que me pasan por parametro
            PreparedStatement pre = con.prepareStatement(sql); //puede lanzar una exepcion , encerramos en un try catch

            pre.setInt(1, id); //seteamos el parametro -remplamos el ? de la linea 87 por un id
            int exito = pre.executeUpdate(); //devolverá un entero
            //guardamos en exito el resultado del executeUpdate
            if (exito == 1) {
                JOptionPane.showMessageDialog(null, "Materia eliminado!");
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "no se pudo eliminar la Materia" + ex.getMessage());
        }
    }
    //-----------------------------------------------------------------------------------------------------------------------------
    
       public List<Materia> listarMaterias() { //
        String sql = "SELECT idMateria,nombre,año,estado FROM materia WHERE estado=1";
        ArrayList<Materia> alumnos = new ArrayList<>();

        try {
            PreparedStatement pre = con.prepareStatement(sql);

            ResultSet re = pre.executeQuery();

            while (re.next()) {
                Materia materia = new Materia();

                materia.setIdMateria(re.getInt("idMateria")); //seteamos datos a materia en base a lo que me devuelve el rs
                materia.setNombre(re.getString("nombre"));
                materia.setAnioMateria(re.getInt("año"));
                materia.setActivo(true);

                alumnos.add(materia);

            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Materia"+ex.getMessage());
        }
        return alumnos;
    }
    //-----------------------------------------------------------------------------------------------------------------------------
}
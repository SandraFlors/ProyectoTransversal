package universidad_grupo3.accesoAdatos;

//import java.sql.* a medida que valla necesitando importar clases sql con esta sentencia las importará
import java.sql.*;

import javax.swing.JOptionPane;

public class Conexion {

    //(final) constantes identificadores en mayuscula
    private static final String URL = "jdbc:mariadb://localhost/"; //(mariadb)=es el driver (localhost)=nos referiamos a nuestro ordenador
    private static final String BD = "universidad"; //nombre de la  base de datos (universidad)
    private static final String USUARIO = "root"; //por defecto el usuario de la bd de mysql es root
    private static final String PASSWORD = ""; //la contraseña es una cadena vacia
    private static Connection connection; //variable statica de tipo conecction , podremos enviar sentencias sql a la base de datos

    //constructor privado
    private Conexion() {
    }

    public static Connection getConexion() { //metodo que se encargará de devolveral exterior la conexion

        //establecer conexion // cargando driver
        if (connection == null) { //si connection==null significa que invocara el metodo por 1era vez
            try {
                Class.forName("org.mariadb.jdbc.Driver");//**si no encuentra la clase driver podria lanzar una exepcion
                //para manejarla encerramos la llamada con un try catch 

                connection = DriverManager.getConnection(URL + BD, USUARIO, PASSWORD);//podria lanzar la sql exepcion en el caso 
                //de que los datos estén incorrectos o me olvide de levantar el administrador la base

            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error al cargar el driver" + ex.getMessage());
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error de coneccion" + ex.getMessage());
            }
        }
        return connection;
    }
}

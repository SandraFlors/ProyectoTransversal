

package universidad_grupo3.accesoAdatos;


import universidad_grupo3.entidades.Inscripcion;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import universidad_grupo3.entidades.Alumno;
import universidad_grupo3.entidades.Materia;


public class InscripcionData {
    private Connection con=null;
    private MateriaData md=new MateriaData();//buscara materia data linea 67/68
    private AlumnoData ad=new AlumnoData();//buscara alumno data
    
    public InscripcionData(){//constructor , inicializamos conexion
        this.con=(Connection) Conexion.getConexion();
    }//se encarga de cargar los drivers de conexion y establecer la misma
    
    //--------------------------------------------------------------------------------------------------------
    public void guardarInscripcion(Inscripcion ins){
        String sql="INSERT INTO inscripcion(idAlumno,idMateria,nota) VALUES ( ?,?,? )";
        
        try {
            PreparedStatement pre=con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            pre.setInt(1, ins.getAlumno().getIdAlumno());
            pre.setInt(2, ins.getMateria().getIdMateria());
            pre.setDouble(3, ins.getNota());//seteamos parametros ? de la linea 31
            pre.executeUpdate();
            
            ResultSet re=pre.getGeneratedKeys(); //lista de claves de todas las inscripsiones , la guardamos en una variables resultset
            if(re.next()){ //si hay claves
                ins.setIdInscripcion(re.getInt(1));
                JOptionPane.showMessageDialog(null, "Inscripcion Registrada Exitosa");
            }
            
            pre.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla para Guardar Inscripcion"+ex.getMessage());
             ex.printStackTrace();
        }
        
    }
    //------------------------------------------------------------------------------------------------------------------------------
    public List<Inscripcion> obtenerInscripciones(){
        ArrayList<Inscripcion>cursadas=new ArrayList<>();
        
        String sql="SELECT * FROM inscripcion";
        
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.executeQuery(); //estamos enviando un select que devuelte un resulset=tantas columnas como tengas la tabla y filas como tenga las inscripciones
        ResultSet res=pre.executeQuery();
        
        while(res.next()){
            Inscripcion ins=new Inscripcion();
            ins.setIdInscripcion(res.getInt("idInscripto"));
           Alumno alu=ad.buscarAlumnoid(res.getInt("idAlumno"));//*
            Materia mat=md.buscarMateria(res.getInt("idMateria"));
            ins.setAlumno(alu);
            ins.setMateria(mat);
            ins.setNota(res.getDouble("nota"));
            cursadas.add(ins); //cada inscripcion se guarda en el arraylist
        }
        pre.close();
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Error al acceder a la tabla para obtener Inscripciones"+ex.getMessage());
        }
        return cursadas;
        
    }
    //------------------------------------------------------------------------------------------------------------------------------
     public List<Inscripcion> obtenerInscripcionesporAlumno(int idAlumno){
        ArrayList<Inscripcion>cursadas=new ArrayList<>();
        
        String sql="SELECT * FROM inscripcion WHERE idAlumno=?";
        
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, idAlumno);
            ResultSet res=pre.executeQuery(); //estamos enviando un select que devuelte un resulset=tantas columnas como tengas la tabla y filas como tenga las inscripciones
       
        
        while(res.next()){
            Inscripcion ins=new Inscripcion();
            ins.setIdInscripcion(res.getInt("idInscripto"));
           Alumno alu=ad.buscarAlumnoid(res.getInt("idAlumno"));//*
            Materia mat=md.buscarMateria(res.getInt("idMateria"));
            ins.setAlumno(alu);
            ins.setMateria(mat);
            ins.setNota(res.getDouble("nota"));
            cursadas.add(ins); //cada inscripcion se guarda en el arraylist
        }
        pre.close();
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Inscripcion por alumno"+ex.getMessage());
        }
        return cursadas;
        
    }
     //------------------------------------------------------------------------------------------------------------------------------
     public List<Materia> obtenerMateriasCursadas(int idAlumno) {
         ArrayList<Materia> materias=new ArrayList<>();
         
         String sql="SELECT inscripcion.idMateria, nombre , año FROM inscripcion, materia WHERE inscripcion.idMateria = materia.idMateria "
                 + " AND inscripcion.idAlumno=?"; //materias solamente en el que alumno esta inscripto , en el from usamos inscripcion y materia
        
        try {
            //se une (producto carteciones)
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, idAlumno);//seteamos ? el valor recibido x parametro
            ResultSet res=pre.executeQuery();
            while(res.next()){
                Materia materia=new Materia();
                materia.setIdMateria(res.getInt("idMateria"));
                materia.setNombre(res.getString("nombre"));
                materia.setAnioMateria(res.getInt("año"));
                materias.add(materia);
            }
            pre.close();
            
        } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Inscripcion de materias cursadas"+ex.getMessage());
          ex.printStackTrace();
        }
         
         return materias;
     }
    //-------------------------------------------------------------------------------------------------------------------------------
     public List<Materia>obtenerMateriasNOCursadas(int idAlumno){
         ArrayList<Materia> materias=new ArrayList<>();
         
         String sql="SELECT * FROM materia Where estado=1 AND idMateria not in ( SELECT idMateria FROM inscripcion WHERE idAlumno=?)";//materias que esten activas
        try {
            //y ademas idmateria no este en el conjunto-------------------
            //---------------------------------------------------------------------id de todas las materias donde esta inscripto un alumno
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, idAlumno);
            ResultSet res=pre.executeQuery();
            while(res.next()){
                Materia materia=new Materia();
                materia.setIdMateria(res.getInt("idMateria"));
                materia.setNombre(res.getString("nombre"));
                materia.setAnioMateria(res.getInt("año"));
                materias.add(materia);
                
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Inscripcion para obtener materias no cursadas"+ex.getMessage());
             ex.printStackTrace();
        }
         
         return materias;
     }
   //--------------------------------------------------------------------------------------------------------------------------------
    public void borrarInscripcionMateriaAlumno(int idAlumno,int idMateria){
        String sql="DELETE FROM inscripcion WHERE idAlumno=? AND idMateria=?";
        
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, idAlumno);
            pre.setInt(2, idMateria);
            int filas=pre.executeUpdate();
            
            if(filas>0){
                JOptionPane.showMessageDialog(null, "Inscripción Borrada Exitosamente!");
            }
            pre.close();
            
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Error al acceder a la tabla  "
                     + "para borrar Inscripcion"+ex.getMessage());
        }
        
    }
    
    //----------------------------------------------------------------------------------------------------------------------------------
    
    public void actualizarNota(int idAlumno, int idMateria, double nota){ //recibe por parametro is de alumno , materia y la nota a actualizar
         String sql="UPDATE inscripcion SET nota=? WHERE idAlumno=? AND idMateria=?";
         
        try {
           
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setDouble(1, nota);
            pre.setInt(2, idAlumno);
            pre.setInt(3, idMateria);
            int resul=pre.executeUpdate();
            if(resul>0){
                 JOptionPane.showMessageDialog(null, "Nota actualizada!");
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al accder a la tabla para actualizar nota"+ex.getMessage());
        }
        
    }
    //------------------------------------------------------------------------------------------
    
    public List<Alumno>obtenerAlumnosporMaterias(int idMateria){
        ArrayList<Alumno>alumnosMateria=new ArrayList<>();
        String sql="SELECT a.idAlumno ,dni,alumno,apellido,fechaNacimiento,estado FROM inscripcion i,alumno a "
                + "WHERE i.idAlumno=a.idAlumno AND idMateria=? AND a.estado=1";
        try {
            PreparedStatement pre=con.prepareStatement(sql);
            pre.setInt(1, idMateria);
            ResultSet res=pre.executeQuery();
            while(res.next()){
                Alumno alumno=new Alumno();
                alumno.setIdAlumno(res.getInt("idAlumno"));
                alumno.setApellido(res.getString("apellido"));
                alumno.setNombre(res.getString("nombre"));
                alumno.setFechaNac(res.getDate("fechaNacimiento").toLocalDate());
                alumno.setActivo(res.getBoolean("estado"));
                alumnosMateria.add(alumno);
            }
            pre.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al accder a la tabla "+ex.getMessage());
        }
        return alumnosMateria;
    }
    
 
    
}


package universidad_grupo3.vistas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import universidad_grupo3.accesoAdatos.AlumnoData;
import universidad_grupo3.accesoAdatos.InscripcionData;
import universidad_grupo3.accesoAdatos.MateriaData;
import universidad_grupo3.entidades.Alumno;
import universidad_grupo3.entidades.Inscripcion;
import universidad_grupo3.entidades.Materia;


public class Inscripciones extends javax.swing.JInternalFrame {
    
    private ArrayList<Materia>listaM;//arraylists
    private ArrayList<Alumno>listaA;
    
    private InscripcionData inscData;//variables de tipo inscripcionData-materia y alumno
    private MateriaData mData;
    private AlumnoData aData;
    
 private DefaultTableModel modelo; //para armar la tabla
   //----------------------------------------------------------------------------
    public Inscripciones() {
        initComponents();
        
        aData =new AlumnoData();
        listaA =(ArrayList<Alumno>)aData.listarAlumnos();
        modelo=new DefaultTableModel();
        cargaAlumnos();
        armarCabeceraTabla();
        
        inscData=new InscripcionData();
        mData=new MateriaData();
    }

   //----------------------------------------------------------------------------
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        lblFormularioInscripcion = new javax.swing.JLabel();
        lblSelecionalumno = new javax.swing.JLabel();
        combo = new javax.swing.JComboBox<>();
        lblListadomaterias = new javax.swing.JLabel();
        radioMateriasinscriptas = new javax.swing.JRadioButton();
        radioMateriasnoinscriptas = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableMaterias = new javax.swing.JTable();
        btnInscribir = new javax.swing.JButton();
        btnAnularinscripcion = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setTitle("Formulario de Inscripción");

        lblFormularioInscripcion.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblFormularioInscripcion.setForeground(new java.awt.Color(0, 0, 0));
        lblFormularioInscripcion.setText("Formulario de Inscripción");

        lblSelecionalumno.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lblSelecionalumno.setForeground(new java.awt.Color(0, 0, 0));
        lblSelecionalumno.setText("Selecciona un alumno:");

        combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboActionPerformed(evt);
            }
        });

        lblListadomaterias.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblListadomaterias.setForeground(new java.awt.Color(0, 0, 0));
        lblListadomaterias.setText("Listado de Materias");

        radioMateriasinscriptas.setForeground(new java.awt.Color(0, 0, 0));
        radioMateriasinscriptas.setText("Materias Inscriptas");
        radioMateriasinscriptas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioMateriasinscriptasActionPerformed(evt);
            }
        });

        radioMateriasnoinscriptas.setForeground(new java.awt.Color(0, 0, 0));
        radioMateriasnoinscriptas.setText("Materias no Inscriptas");
        radioMateriasnoinscriptas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioMateriasnoinscriptasActionPerformed(evt);
            }
        });

        tableMaterias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tableMaterias);

        btnInscribir.setForeground(new java.awt.Color(0, 0, 0));
        btnInscribir.setText("Inscribir");
        btnInscribir.setEnabled(false);
        btnInscribir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInscribirActionPerformed(evt);
            }
        });

        btnAnularinscripcion.setForeground(new java.awt.Color(0, 0, 0));
        btnAnularinscripcion.setText("Anular Inscripcion");
        btnAnularinscripcion.setEnabled(false);
        btnAnularinscripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnularinscripcionActionPerformed(evt);
            }
        });

        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jDesktopPane1.setLayer(lblFormularioInscripcion, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(lblSelecionalumno, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(combo, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(lblListadomaterias, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(radioMateriasinscriptas, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(radioMateriasnoinscriptas, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(btnInscribir, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(btnAnularinscripcion, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(btnSalir, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(lblFormularioInscripcion))
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(lblListadomaterias))
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                                .addComponent(radioMateriasinscriptas)
                                .addGap(44, 44, 44)
                                .addComponent(radioMateriasnoinscriptas))
                            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                                .addComponent(lblSelecionalumno)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(combo, 0, 219, Short.MAX_VALUE))))
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(btnInscribir)
                .addGap(53, 53, 53)
                .addComponent(btnAnularinscripcion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(59, 59, 59))
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(lblFormularioInscripcion)
                .addGap(18, 18, 18)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSelecionalumno)
                    .addComponent(combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lblListadomaterias)
                .addGap(18, 18, 18)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(radioMateriasinscriptas)
                    .addComponent(radioMateriasnoinscriptas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInscribir)
                    .addComponent(btnAnularinscripcion)
                    .addComponent(btnSalir))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 153, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void cargaAlumnos(){ //cargará el combo box
    for(Alumno item:listaA){
        combo.addItem(item);
    }
}
//-----------------------------------------------------------------------------------
private void armarCabeceraTabla(){ //creara la tabla
    ArrayList<Object>filaCabecera=new ArrayList<>();
    filaCabecera.add("ID");
    filaCabecera.add("Nombre");
    filaCabecera.add("Año");
    for(Object it:filaCabecera){ 
        modelo.addColumn(it);
    }
    tableMaterias.setModel(modelo);
}
//------------------------------------------------------------------------------------
private void borrarFilaTabla(){
    int indice=modelo.getRowCount()-1;
    
    for(int i=indice;i>=0;i--){
        modelo.removeRow(i); //removera filas con el indice
    }
}
//-------------------------------------------------------------------------------------
private void cargaDatosNoIns(){
    Alumno selec=(Alumno)combo.getSelectedItem();
    listaM=(ArrayList) inscData.obtenerMateriasNOCursadas(selec.getIdAlumno());
    for(Materia m:listaM){
        modelo.addRow(new Object[]{m.getIdMateria(),m.getNombre(),m.getAnioMateria()} );
    }
}
//-------------------------------------------------------------------------------------
private void cargaDatosIns(){
    Alumno selec=(Alumno)combo.getSelectedItem();
    List<Materia> lista=(ArrayList) inscData.obtenerMateriasCursadas(selec.getIdAlumno());
    for(Materia m : lista){
        modelo.addRow(new Object[]{m.getIdMateria(),m.getNombre(),m.getAnioMateria() });
    }
}
//-------------------------------------------------------------------------------------

    private void comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboActionPerformed

    private void radioMateriasinscriptasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioMateriasinscriptasActionPerformed
        // MATERIAS INSCRIPTAS
        borrarFilaTabla(); //aseguramos que la tabla este vacia
        radioMateriasnoinscriptas.setSelected(false); //desabiloitamos el radio materias no inscriptas
        cargaDatosIns();
        btnInscribir.setEnabled(true);//habilitamos el boton
        btnAnularinscripcion.setEnabled(false);//desabiloitamos el boton
        
    }//GEN-LAST:event_radioMateriasinscriptasActionPerformed

    private void radioMateriasnoinscriptasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioMateriasnoinscriptasActionPerformed
        // MATERIAS NO INSCRIPTAS
        borrarFilaTabla();
        radioMateriasinscriptas.setSelected(false);//desactivamos el boton
        cargaDatosNoIns();
        btnAnularinscripcion.setEnabled(false);
        btnInscribir.setEnabled(true);
    }//GEN-LAST:event_radioMateriasnoinscriptasActionPerformed

    private void btnInscribirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInscribirActionPerformed
        // INSCRIBIR
        int filaSelec=tableMaterias.getSelectedRow();
        if(filaSelec!=+1){ 
            Alumno a=(Alumno)combo.getSelectedItem();
            int idMateria=(Integer)modelo.getValueAt(filaSelec, 0);
            String nombremateria=(String)modelo.getValueAt(filaSelec, 1);
            int anio=(Integer)modelo.getValueAt(filaSelec, 2);
            Materia m=new Materia(idMateria,nombremateria,anio,true);
            Inscripcion i=new Inscripcion(a,m,0);
            inscData.guardarInscripcion(i);
            borrarFilaTabla();
        }
    }//GEN-LAST:event_btnInscribirActionPerformed
//----------------------------------------------------------------------------------------
    private void btnAnularinscripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnularinscripcionActionPerformed
        // ANULAR INSCRIPCION
        int filaSeleccionada=tableMaterias.getSelectedRow();
        if(filaSeleccionada!=+1){
            Alumno a=(Alumno)combo.getSelectedItem();
            int idMateria=(Integer)modelo.getValueAt(filaSeleccionada, 0);
            inscData.borrarInscripcionMateriaAlumno(a.getIdAlumno(), idMateria);
            borrarFilaTabla();
        }
    }//GEN-LAST:event_btnAnularinscripcionActionPerformed
//-------------------------------------------------------------------------------------
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // Salir
        dispose();
    }//GEN-LAST:event_btnSalirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnularinscripcion;
    private javax.swing.JButton btnInscribir;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<Alumno> combo;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblFormularioInscripcion;
    private javax.swing.JLabel lblListadomaterias;
    private javax.swing.JLabel lblSelecionalumno;
    private javax.swing.JRadioButton radioMateriasinscriptas;
    private javax.swing.JRadioButton radioMateriasnoinscriptas;
    private javax.swing.JTable tableMaterias;
    // End of variables declaration//GEN-END:variables

  
}


package universidad_grupo3.vistas;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import universidad_grupo3.accesoAdatos.AlumnoData;
import universidad_grupo3.accesoAdatos.InscripcionData;
import universidad_grupo3.accesoAdatos.MateriaData;
import universidad_grupo3.entidades.Alumno;
import universidad_grupo3.entidades.Materia;


public class ActualizaciondeNotas extends javax.swing.JInternalFrame {
private ArrayList<Alumno>listaA;
private ArrayList<Materia>listaM;
 private InscripcionData inscData;
private MateriaData mData;
private AlumnoData aData;

private DefaultTableModel modelo; //atributo para armar la JTable
//------------------------------------------------------------------------------
    

    public ActualizaciondeNotas() {
        initComponents();
        aData= new AlumnoData();
        listaA= (ArrayList<Alumno>) aData.listarAlumnos();
        modelo=new DefaultTableModel();
        mData=new MateriaData();
        inscData = new InscripcionData();
        
        cargaAlumnos();//metodo
        armarCabeceraTabla();//metodo
         materiasCuarsadas();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        lblCarganotas = new javax.swing.JLabel();
        lblSeleccionaAlumno = new javax.swing.JLabel();
        comboAlumnoseleccion = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableNotas = new javax.swing.JTable();
        btnGuardar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setTitle("Carga de notas");

        lblCarganotas.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblCarganotas.setForeground(new java.awt.Color(0, 0, 0));
        lblCarganotas.setText("Carga de notas");

        lblSeleccionaAlumno.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lblSeleccionaAlumno.setForeground(new java.awt.Color(0, 0, 0));
        lblSeleccionaAlumno.setText("Selecciona un Alumno:");

        comboAlumnoseleccion.setToolTipText("");
        comboAlumnoseleccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboAlumnoseleccionActionPerformed(evt);
            }
        });

        tableNotas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableNotas);

        btnGuardar.setForeground(new java.awt.Color(0, 0, 0));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jDesktopPane1.setLayer(lblCarganotas, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(lblSeleccionaAlumno, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(comboAlumnoseleccion, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(btnGuardar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(btnSalir, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(lblCarganotas)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(btnGuardar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(85, 85, 85))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDesktopPane1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblSeleccionaAlumno)
                .addGap(19, 19, 19)
                .addComponent(comboAlumnoseleccion, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(lblCarganotas)
                .addGap(18, 18, 18)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSeleccionaAlumno)
                    .addComponent(comboAlumnoseleccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnSalir))
                .addGap(37, 37, 37))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 51, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboAlumnoseleccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboAlumnoseleccionActionPerformed
        // COMBO BOX
      
    }//GEN-LAST:event_comboAlumnoseleccionActionPerformed
public void cargaAlumnos() { //recorrer la lista de alumno y setearsela al ComboBox
    
    for(Materia item: listaM) { 
        comboAlumnoseleccion.addItem(item);
    }
}
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        //BOTON SALIR
        dispose(); //metodo salir
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // BOTON GUARDAR
        
    }//GEN-LAST:event_btnGuardarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<Materia> comboAlumnoseleccion;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCarganotas;
    private javax.swing.JLabel lblSeleccionaAlumno;
    private javax.swing.JTable tableNotas;
    // End of variables declaration//GEN-END:variables

    private void armarCabeceraTabla() {
        ArrayList<Object> filas=new ArrayList<>(); //arraylist de objetos
        filas.add("Id"); //titulos de la cabezera de la tabla
        filas.add("Nombre");
        filas.add("Nota");
        
        for(Object item:filas) { //con el for recorremos el arraylist y al modelo le agregamos las columnas
            modelo.addColumn(modelo);
        }
        tableNotas.setModel(modelo);//le seteamos el modelo a la tabla
    }
    private void materiasCuarsadas() { 
        Alumno selec= (Alumno) comboAlumnoseleccion.getSelectedItem();
        inscData.obtenerMateriasCursadas(selec.getIdAlumno());
        for(Materia m: listaM) { 
            modelo.addRow(new Object[]  {m.getIdMateria(),m.getNombre(),m.getAnioMateria()} );
        }
    }
}

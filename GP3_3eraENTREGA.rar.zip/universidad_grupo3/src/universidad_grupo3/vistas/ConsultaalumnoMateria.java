
package universidad_grupo3.vistas;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import universidad_grupo3.accesoAdatos.AlumnoData;
import universidad_grupo3.accesoAdatos.InscripcionData;
import universidad_grupo3.accesoAdatos.MateriaData;
import universidad_grupo3.entidades.Alumno;
import universidad_grupo3.entidades.Materia;


public class ConsultaalumnoMateria extends javax.swing.JInternalFrame {

   private ArrayList<Materia>listaM;
   private ArrayList<Alumno>listaA;
   
   private MateriaData mData;
   private AlumnoData aData;
   
   private InscripcionData inscData;
   
   private DefaultTableModel modelo;
   //-------------------------------------------------------------------
    public ConsultaalumnoMateria() {
        initComponents();
        
        aData =new AlumnoData();
        listaA= (ArrayList<Alumno>) aData.listarAlumnos();
        modelo =new DefaultTableModel();
        
        cargaMaterias();
        inscData=new InscripcionData();
        mData=new MateriaData();
        
        cargaMaterias();
        armarCabecera();
        cargaAlumnosMateria();
    }

  //---------------------------------------------------------------------------
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        lblListadoAlumMaterias = new javax.swing.JLabel();
        lblSellecionMateria = new javax.swing.JLabel();
        comboMateria = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableAlumnosxMateria = new javax.swing.JTable();
        btnSalir = new javax.swing.JButton();

        setTitle("Listado de Alumnos por Materia");

        lblListadoAlumMaterias.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblListadoAlumMaterias.setForeground(new java.awt.Color(0, 0, 0));
        lblListadoAlumMaterias.setText("Listado de Alumnos por Materia");

        lblSellecionMateria.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lblSellecionMateria.setForeground(new java.awt.Color(0, 0, 0));
        lblSellecionMateria.setText("Seleccioná una materia:");

        tableAlumnosxMateria.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableAlumnosxMateria);

        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jDesktopPane1.setLayer(lblListadoAlumMaterias, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(lblSellecionMateria, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(comboMateria, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(btnSalir, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDesktopPane1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnSalir))
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(lblListadoAlumMaterias)
                        .addGap(0, 62, Short.MAX_VALUE))
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(lblSellecionMateria)
                        .addGap(18, 18, 18)
                        .addComponent(comboMateria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lblListadoAlumMaterias)
                .addGap(18, 18, 18)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSellecionMateria)
                    .addComponent(comboMateria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        //BOTON SALIR
        dispose();
    }//GEN-LAST:event_btnSalirActionPerformed
 private void cargaMaterias() { //carga el comboBox de materias
     for(Materia m:listaM) { 
         comboMateria.addItem(m);
     }
 }
 private void armarCabecera(){
     ArrayList<Object>fila=new ArrayList<>();
     fila.add("ID");
     fila.add("DNI");
     fila.add("Apellido");
     fila.add("Nombre");
     for(Object o:fila){
         modelo.addColumn(modelo);
     }
     tableAlumnosxMateria.setModel(modelo);
 }
 private void cargaAlumnosMateria(){
     Materia selec= (Materia) comboMateria.getSelectedItem();
     listaA= (ArrayList<Alumno>) inscData.obtenerAlumnosporMaterias(selec.getIdMateria());
     for(Alumno a:listaA){
         modelo.addRow(new Object[] {a.getIdAlumno(),a.getDni(),a.getApellido(),a.getNombre() } );
     }
 }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<Materia> comboMateria;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblListadoAlumMaterias;
    private javax.swing.JLabel lblSellecionMateria;
    private javax.swing.JTable tableAlumnosxMateria;
    // End of variables declaration//GEN-END:variables
}

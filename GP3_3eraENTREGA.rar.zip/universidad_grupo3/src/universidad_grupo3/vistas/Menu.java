
package universidad_grupo3.vistas;


public class Menu extends javax.swing.JFrame {

    
    public Menu() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Escritorio = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuAlumno = new javax.swing.JMenu();
        menuFormularioAlumno = new javax.swing.JMenuItem();
        muenuMateria = new javax.swing.JMenu();
        menuFormularioMateria = new javax.swing.JMenuItem();
        manuAdministraciohn = new javax.swing.JMenu();
        menuInscripciones = new javax.swing.JMenuItem();
        menuNotas = new javax.swing.JMenuItem();
        menuConsultas = new javax.swing.JMenu();
        menuAlumnosporMateria = new javax.swing.JMenuItem();
        menuSalir = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout EscritorioLayout = new javax.swing.GroupLayout(Escritorio);
        Escritorio.setLayout(EscritorioLayout);
        EscritorioLayout.setHorizontalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        EscritorioLayout.setVerticalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 305, Short.MAX_VALUE)
        );

        menuAlumno.setText("Alumno");

        menuFormularioAlumno.setText("Formulario de Alumno");
        menuFormularioAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFormularioAlumnoActionPerformed(evt);
            }
        });
        menuAlumno.add(menuFormularioAlumno);

        jMenuBar1.add(menuAlumno);

        muenuMateria.setText("Materia");

        menuFormularioMateria.setText("Formulario de Materia");
        menuFormularioMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFormularioMateriaActionPerformed(evt);
            }
        });
        muenuMateria.add(menuFormularioMateria);

        jMenuBar1.add(muenuMateria);

        manuAdministraciohn.setText("Administración");

        menuInscripciones.setText("Manejo de Inscripciones");
        menuInscripciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuInscripcionesActionPerformed(evt);
            }
        });
        manuAdministraciohn.add(menuInscripciones);

        menuNotas.setText("Manipulación de notas");
        menuNotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuNotasActionPerformed(evt);
            }
        });
        manuAdministraciohn.add(menuNotas);

        jMenuBar1.add(manuAdministraciohn);

        menuConsultas.setText("Consultas");

        menuAlumnosporMateria.setText("Alumnos por Materia");
        menuAlumnosporMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuAlumnosporMateriaActionPerformed(evt);
            }
        });
        menuConsultas.add(menuAlumnosporMateria);

        jMenuBar1.add(menuConsultas);

        menuSalir.setText("Salir");
        menuSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSalirActionPerformed(evt);
            }
        });
        jMenuBar1.add(menuSalir);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Escritorio)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Escritorio)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuFormularioAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFormularioAlumnoActionPerformed
        Escritorio.removeAll();
        Escritorio.repaint();
        GestiondeAlumnos alumno=new GestiondeAlumnos();
        alumno.setVisible(true);
        Escritorio.add(alumno);
    }//GEN-LAST:event_menuFormularioAlumnoActionPerformed

    private void menuFormularioMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFormularioMateriaActionPerformed
        Escritorio.removeAll();
        Escritorio.repaint();
        GestiondeMaterias materias=new GestiondeMaterias();
        materias.setVisible(true);
        Escritorio.add(materias);
    }//GEN-LAST:event_menuFormularioMateriaActionPerformed

    private void menuInscripcionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuInscripcionesActionPerformed
        Escritorio.removeAll();
        Escritorio.repaint();
        Inscripciones ins=new Inscripciones();
       ins.setVisible(true);
        Escritorio.add(ins);
    }//GEN-LAST:event_menuInscripcionesActionPerformed

    private void menuNotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuNotasActionPerformed
       Escritorio.removeAll();
        Escritorio.repaint();
        ActualizaciondeNotas notas=new ActualizaciondeNotas();
        notas.setVisible(true);
        Escritorio.add(notas);
    }//GEN-LAST:event_menuNotasActionPerformed

    private void menuAlumnosporMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuAlumnosporMateriaActionPerformed
        Escritorio.removeAll();
        Escritorio.repaint();
        ConsultaalumnoMateria mt=new ConsultaalumnoMateria();
        mt.setVisible(true);
        Escritorio.add(mt);
    }//GEN-LAST:event_menuAlumnosporMateriaActionPerformed

    private void menuSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSalirActionPerformed
       System.exit(0);
    }//GEN-LAST:event_menuSalirActionPerformed

 
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
      

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane Escritorio;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu manuAdministraciohn;
    private javax.swing.JMenu menuAlumno;
    private javax.swing.JMenuItem menuAlumnosporMateria;
    private javax.swing.JMenu menuConsultas;
    private javax.swing.JMenuItem menuFormularioAlumno;
    private javax.swing.JMenuItem menuFormularioMateria;
    private javax.swing.JMenuItem menuInscripciones;
    private javax.swing.JMenuItem menuNotas;
    private javax.swing.JMenu menuSalir;
    private javax.swing.JMenu muenuMateria;
    // End of variables declaration//GEN-END:variables
}
